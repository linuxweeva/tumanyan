<footer class="footer bg-success py-5">
	<h2 class="text-center text-white">Footer</h2>
</footer>