<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

<div>
	<div class="owl-carousel owl-theme">
	    <div class="item">
	    	<img src="/mock/slide.jpeg" />
	    </div>
	    <div class="item"><h4>2</h4></div>
	    <div class="item"><h4>3</h4></div>
	    <div class="item"><h4>4</h4></div>
	    <div class="item"><h4>5</h4></div>
	    <div class="item"><h4>6</h4></div>
	    <div class="item"><h4>7</h4></div>
	    <div class="item"><h4>8</h4></div>
	    <div class="item"><h4>9</h4></div>
	    <div class="item"><h4>10</h4></div>
	    <div class="item"><h4>11</h4></div>
	    <div class="item"><h4>12</h4></div>
	</div>

</div>