<footer class="footer bg-primary py-5 text-center">
	<h2 class="text-white">{{ __( 'Admin' ) }}</h2>
</footer>