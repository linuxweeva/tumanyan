@extends( 'layouts.admin' )

@section( 'content' )
<div class="">
    <div class="row justify-content-center">
        Welcome admin
    </div>
</div>
@endsection
