<div class="text-center">
	<h3>{{ __( "Subscribe to news" ) }}</h3>
	<div id='email_subscription_form' class="row justify-content-center">
		<div class="form-group  pr-1 mr-0">
			<input type="email" class="form-control" value="" placeholder="{{ __( 'E-mail address' ) }}" />
		</div>
		<div class="form-group px-0 mx-0">
			<button class="btn btn-primary">
				<i class="fas fa fas-check fa-check"></i>
			</button>
		</div>
	</div>
</div>