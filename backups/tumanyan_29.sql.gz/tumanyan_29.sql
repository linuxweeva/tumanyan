-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: tumanyan
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_am` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (1,'author1','author12','author123\r\n',NULL,'2021-05-28 18:08:36',1),(2,'Tumanyan','Туманян','Toumanian','2021-05-25 21:39:22','2021-05-25 21:39:22',0),(3,'Amerikyan1','Amerikyanski','USA','2021-05-25 21:39:58','2021-05-28 18:08:32',1),(5,'Avetisyan','Аветисян','Avetissyan','2021-05-28 18:08:54','2021-05-28 18:08:54',0),(6,'Dostotyevskiyna gre','Достоевский','Dostoevsky','2021-05-28 18:25:43','2021-05-28 18:25:43',0),(7,'Shekspirna gre','Шекспир','Shakespeare','2021-05-28 18:26:25','2021-05-28 18:26:25',0);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_am` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned NOT NULL,
  `publish_info_am` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publish_info_ru` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish_info_en` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_id` bigint unsigned NOT NULL,
  `type_id` bigint unsigned NOT NULL,
  `price` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (11,'Ereq xozuknery','Tri parasyata','Three schwaine',2,7,'Pulblished by Tumanyan','Pulblished by Tumanyanru','Pulblished by Tumanyanen',1,6,1500000,'2021-05-27 12:11:40','2021-05-28 18:29:41'),(12,'Kikosi mahy','kikos smert','Kikos death',2,7,'Joxovuird','narod','People',1,6,0,'2021-05-27 12:15:43','2021-05-28 18:31:23'),(13,'Victor hugon a','Виктор Иуда',NULL,2,7,'Publish en are verjers',NULL,'Published lately',6,5,0,'2021-05-28 18:28:05','2021-05-28 18:35:31'),(14,'Debily','Идиот','The idiot',6,8,'Publish a arve soveti vaxterov','Советская публикация','Published by Lenin',5,5,0,'2021-05-28 18:29:46','2021-05-28 18:29:46');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donations`
--

DROP TABLE IF EXISTS `donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `amount` bigint unsigned NOT NULL DEFAULT '0',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donations`
--

LOCK TABLES `donations` WRITE;
/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `book_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
INSERT INTO `favorites` VALUES (41,13,1,'2021-05-28 18:39:33','2021-05-28 18:39:33');
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_id` bigint unsigned NOT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `absolute_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tmp_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'full',2279029329800,100,'/var/www/tumanyan/public/pdf/2279029329800//full_88.pdf','/pdf/2279029329800//full_88.pdf','https://tumanyan.atata.icu/pdf/2279029329800//full_88.pdf','2021-05-25 10:20:48','2021-05-25 10:20:48',NULL),(2,'full',2279029329800,1368559,'/var/www/tumanyan/public/pdf/2279029329800//full_43.pdf','/pdf/2279029329800//full_43.pdf','https://tumanyan.atata.icu/pdf/2279029329800//full_43.pdf','2021-05-25 10:21:58','2021-05-25 10:21:58',NULL),(3,'full',2279029329800,1368559,'/var/www/tumanyan/public/pdf/2279029329800//full_47.pdf','/pdf2279029329800//full_47.pdf','https://tumanyan.atata.icu/pdf2279029329800//full_47.pdf','2021-05-25 10:22:35','2021-05-25 10:22:35',NULL),(4,'full',2279029329800,1368559,'/var/www/tumanyan/public/pdf/2279029329800//full_63.pdf','/pdf/2279029329800/full_63.pdf','https://tumanyan.atata.icu/pdf/2279029329800/full_63.pdf','2021-05-25 10:22:49','2021-05-25 10:22:49',NULL),(5,'full',1133248463019,1368559,'/var/www/tumanyan/public/pdf/1133248463019//full_94.pdf','/pdf/1133248463019/full_94.pdf','https://tumanyan.atata.icu/pdf/1133248463019/full_94.pdf','2021-05-25 10:24:35','2021-05-25 10:24:35',NULL),(6,'full',1764106414001,1368559,'/var/www/tumanyan/public/pdf/1764106414001//full_89.pdf','/pdf/1764106414001/full_89.pdf','https://tumanyan.atata.icu/pdf/1764106414001/full_89.pdf','2021-05-25 10:24:50','2021-05-25 10:24:50',NULL),(7,'full',416459802459,1368559,'/var/www/tumanyan/public/pdf/416459802459//full_84.pdf','/pdf/416459802459/full_84.pdf','https://tumanyan.atata.icu/pdf/416459802459/full_84.pdf','2021-05-25 10:25:00','2021-05-25 10:25:00',NULL),(8,'full',1302524255678,1368559,'/var/www/tumanyan/public/pdf/1302524255678//full_38.pdf','/pdf/1302524255678/full_38.pdf','https://tumanyan.atata.icu/pdf/1302524255678/full_38.pdf','2021-05-25 10:25:26','2021-05-25 10:25:26',NULL),(9,'full',951447153182,1368559,'/var/www/tumanyan/public/pdf/951447153182//full_13.pdf','/pdf/951447153182/full_13.pdf','https://tumanyan.atata.icu/pdf/951447153182/full_13.pdf','2021-05-25 10:26:28','2021-05-25 10:26:28',NULL),(10,'full',1986086929323,1368559,'/var/www/tumanyan/public/pdf/1986086929323//full_93.pdf','/pdf/1986086929323/full_93.pdf','https://tumanyan.atata.icu/pdf/1986086929323/full_93.pdf','2021-05-25 10:26:52','2021-05-25 10:26:52',NULL),(11,'full',1986086929323,1368559,'/var/www/tumanyan/public/pdf/1986086929323//full_39.pdf','/pdf/1986086929323/full_39.pdf','https://tumanyan.atata.icu/pdf/1986086929323/full_39.pdf','2021-05-25 10:26:54','2021-05-25 10:26:54',NULL),(12,'full',1928211886742,1368559,'/var/www/tumanyan/public/pdf/1928211886742//full_22.pdf','/pdf/1928211886742/full_22.pdf','https://tumanyan.atata.icu/pdf/1928211886742/full_22.pdf','2021-05-25 10:30:31','2021-05-25 10:30:31',NULL),(13,'full',184794105690,1368559,'/var/www/tumanyan/public/pdf/184794105690//full_91.pdf','/pdf/184794105690/full_91.pdf','https://tumanyan.atata.icu/pdf/184794105690/full_91.pdf','2021-05-25 18:39:06','2021-05-25 18:39:06',NULL),(14,'full',1519034448373,1368559,'/var/www/tumanyan/public/pdf/1519034448373//full_50.pdf','/pdf/1519034448373/full_50.pdf','https://tumanyan.atata.icu/pdf/1519034448373/full_50.pdf','2021-05-25 18:39:51','2021-05-25 18:39:51',NULL),(15,'full',1358538842428,1368559,'/var/www/tumanyan/public/pdf/1358538842428//full_78.pdf','/pdf/1358538842428/full_78.pdf','https://tumanyan.atata.icu/pdf/1358538842428/full_78.pdf','2021-05-25 18:40:04','2021-05-25 18:40:04',NULL),(16,'full',1349405397024,1368559,'/var/www/tumanyan/public/pdf/1349405397024//full_19.pdf','/pdf/1349405397024/full_19.pdf','https://tumanyan.atata.icu/pdf/1349405397024/full_19.pdf','2021-05-25 18:42:29','2021-05-25 18:42:29',NULL),(17,'full',322055571229,1368559,'/var/www/tumanyan/public/pdf/322055571229//full_41.pdf','/pdf/322055571229/full_41.pdf','https://tumanyan.atata.icu/pdf/322055571229/full_41.pdf','2021-05-25 18:43:22','2021-05-25 18:43:22',NULL),(18,'pdf',2102824859960,1368559,'/var/www/tumanyan/public/pdf/2102824859960//pdf_63.pdf','/pdf/2102824859960/pdf_63.pdf','https://tumanyan.atata.icu/pdf/2102824859960/pdf_63.pdf','2021-05-25 18:44:14','2021-05-25 18:44:14',NULL),(19,'pdf_partial',2102824859960,1368559,'/var/www/tumanyan/public/pdf/2102824859960//pdf_partial_34.pdf','/pdf/2102824859960/pdf_partial_34.pdf','https://tumanyan.atata.icu/pdf/2102824859960/pdf_partial_34.pdf','2021-05-25 18:44:17','2021-05-25 18:44:17',NULL),(20,'pdf',16125597172,1368559,'/var/www/tumanyan/public/pdf/16125597172//pdf_33.pdf','/pdf/16125597172/pdf_33.pdf','https://tumanyan.atata.icu/pdf/16125597172/pdf_33.pdf','2021-05-25 18:45:04','2021-05-25 18:45:04',NULL),(21,'pdf_partial',16125597172,55186,'/var/www/tumanyan/public/pdf/16125597172//pdf_partial_75.pdf','/pdf/16125597172/pdf_partial_75.pdf','https://tumanyan.atata.icu/pdf/16125597172/pdf_partial_75.pdf','2021-05-25 18:45:07','2021-05-25 18:45:07',NULL),(22,'pdf',140472517140,1368559,'/var/www/tumanyan/public/pdf/140472517140//pdf_26.pdf','/pdf/140472517140/pdf_26.pdf','https://tumanyan.atata.icu/pdf/140472517140/pdf_26.pdf','2021-05-25 18:45:19','2021-05-25 18:45:19',NULL),(23,'pdf',1913201128102,1368559,'/var/www/tumanyan/public/pdf/1913201128102//pdf_43.pdf','/pdf/1913201128102/pdf_43.pdf','https://tumanyan.atata.icu/pdf/1913201128102/pdf_43.pdf','2021-05-25 18:45:27','2021-05-25 18:45:27',NULL),(24,'pdf_partial',1913201128102,55186,'/var/www/tumanyan/public/pdf/1913201128102//pdf_partial_62.pdf','/pdf/1913201128102/pdf_partial_62.pdf','https://tumanyan.atata.icu/pdf/1913201128102/pdf_partial_62.pdf','2021-05-25 18:45:30','2021-05-25 18:45:30',NULL),(25,'pdf',280580214384,1368559,'/var/www/tumanyan/public/pdf/280580214384//pdf_42.pdf','/pdf/280580214384/pdf_42.pdf','https://tumanyan.atata.icu/pdf/280580214384/pdf_42.pdf','2021-05-25 18:47:24','2021-05-25 18:47:24',NULL),(26,'pdf',2031712695921,3028,'/var/www/tumanyan/public/pdf/2031712695921//pdf_72.pdf','/pdf/2031712695921/pdf_72.pdf','https://tumanyan.atata.icu/pdf/2031712695921/pdf_72.pdf','2021-05-25 18:52:09','2021-05-25 18:52:09',NULL),(28,'pdf',657487235554,3028,'/var/www/tumanyan/public/pdf/657487235554//pdf_34.pdf','/pdf/657487235554/pdf_34.pdf','https://tumanyan.atata.icu/pdf/657487235554/pdf_34.pdf','2021-05-25 19:03:43','2021-05-25 19:03:43',657487235554),(29,'pdf',1961840041540,3028,'/var/www/tumanyan/public/pdf/1961840041540//pdf_70.pdf','/pdf/1961840041540/pdf_70.pdf','https://tumanyan.atata.icu/pdf/1961840041540/pdf_70.pdf','2021-05-25 19:16:26','2021-05-25 19:16:26',1961840041540),(32,'pdf',8,3028,'/var/www/tumanyan/public/pdf/5//pdf_48.pdf','/pdf/5/pdf_48.pdf','https://tumanyan.atata.icu/pdf/5/pdf_48.pdf','2021-05-25 19:17:36','2021-05-25 19:18:36',5),(33,'pdf_partial',8,3028,'/var/www/tumanyan/public/pdf/5//pdf_partial_73.pdf','/pdf/5/pdf_partial_73.pdf','https://tumanyan.atata.icu/pdf/5/pdf_partial_73.pdf','2021-05-25 19:17:39','2021-05-25 19:18:36',5),(34,'pdf',4,3028,'/var/www/tumanyan/public/pdf/4//pdf_39.pdf','/pdf/4/pdf_39.pdf','https://tumanyan.atata.icu/pdf/4/pdf_39.pdf','2021-05-25 19:20:37','2021-05-25 19:20:37',4),(35,'pdf',9,3028,'/var/www/tumanyan/public/pdf/1325271915989//pdf_93.pdf','/pdf/1325271915989/pdf_93.pdf','https://tumanyan.atata.icu/pdf/1325271915989/pdf_93.pdf','2021-05-25 21:40:42','2021-05-25 21:40:47',1325271915989),(41,'pdf_partial',9,8871222,'/var/www/tumanyan/public/pdf/9//pdf_partial_58.pdf','/pdf/9/pdf_partial_58.pdf','https://tumanyan.atata.icu/pdf/9/pdf_partial_58.pdf','2021-05-26 00:38:24','2021-05-26 00:38:24',9),(56,'image',9,273413,'/var/www/tumanyan/public/pdf/9//image_44.png','/pdf/9/image_44.png','https://tumanyan.atata.icu/pdf/9/image_44.png','2021-05-26 00:47:01','2021-05-26 00:47:01',9),(57,'image',829685835392,273413,'/var/www/tumanyan/public/pdf/829685835392//image_97.png','/pdf/829685835392/image_97.png','https://tumanyan.atata.icu/pdf/829685835392/image_97.png','2021-05-26 00:48:23','2021-05-26 00:48:23',829685835392),(58,'image',1654241576767,273413,'/var/www/tumanyan/public/pdf/1654241576767//image_86.png','/pdf/1654241576767/image_86.png','https://tumanyan.atata.icu/pdf/1654241576767/image_86.png','2021-05-26 00:51:55','2021-05-26 00:51:55',1654241576767),(62,'pdf',10,8871222,'/var/www/tumanyan/public/uploads/10//pdf.pdf','/uploads/10/pdf.pdf','https://tumanyan.atata.icu/uploads/10/pdf.pdf','2021-05-27 10:34:01','2021-05-27 10:34:01',10),(63,'pdf_partial',10,33662,'/var/www/tumanyan/public/uploads/10//pdf_partial.pdf','/uploads/10/pdf_partial.pdf','https://tumanyan.atata.icu/uploads/10/pdf_partial.pdf','2021-05-27 10:35:28','2021-05-27 10:35:28',10),(64,'image',10,1986973,'/var/www/tumanyan/public/uploads/10//image.jpg','/uploads/10/image.jpg','https://tumanyan.atata.icu/uploads/10/image.jpg','2021-05-27 10:35:34','2021-05-27 10:35:34',10),(69,'partial',10,33662,'/var/www/tumanyan/public/uploads/10//partial.pdf','/uploads/10/partial.pdf','https://tumanyan.atata.icu/uploads/10/partial.pdf','2021-05-27 11:00:18','2021-05-27 11:00:18',10),(75,'full',10,8871222,'/var/www/tumanyan/public/uploads/10//full.pdf','/uploads/10/full.pdf','https://tumanyan.atata.icu/uploads/10/full.pdf','2021-05-27 12:06:04','2021-05-27 12:06:04',10),(76,'full',11,1066141,'/var/www/tumanyan/public/uploads/1196614593490//full.pdf','/uploads/1196614593490/full.pdf','https://tumanyan.atata.icu/uploads/1196614593490/full.pdf','2021-05-27 12:10:45','2021-05-27 12:11:40',1196614593490),(78,'partial',11,1368559,'/var/www/tumanyan/public/uploads/1196614593490//pdf_partial.pdf','/uploads/1196614593490/pdf_partial.pdf','https://tumanyan.atata.icu/uploads/1196614593490/pdf_partial.pdf','2021-05-27 12:11:13','2021-05-27 12:11:40',1196614593490),(79,'image',11,1986973,'/var/www/tumanyan/public/uploads/1196614593490//image.jpg','/uploads/1196614593490/image.jpg','https://tumanyan.atata.icu/uploads/1196614593490/image.jpg','2021-05-27 12:11:37','2021-05-27 12:11:40',1196614593490),(80,'full',12,754498,'/var/www/tumanyan/public/uploads/1612705478637//full.pdf','/uploads/1612705478637/full.pdf','https://tumanyan.atata.icu/uploads/1612705478637/full.pdf','2021-05-27 12:15:26','2021-05-27 12:15:43',1612705478637),(81,'partial',12,33662,'/var/www/tumanyan/public/uploads/1612705478637//pdf_partial.pdf','/uploads/1612705478637/pdf_partial.pdf','https://tumanyan.atata.icu/uploads/1612705478637/pdf_partial.pdf','2021-05-27 12:15:37','2021-05-27 12:15:43',1612705478637),(82,'full',13,347242,'/var/www/tumanyan/public/uploads/116257785883//full.pdf','/uploads/116257785883/full.pdf','https://tumanyan.atata.icu/uploads/116257785883/full.pdf','2021-05-28 18:27:59','2021-05-28 18:28:05',116257785883),(83,'full',14,2732157,'/var/www/tumanyan/public/uploads/1663504095587//full.pdf','/uploads/1663504095587/full.pdf','https://tumanyan.atata.icu/uploads/1663504095587/full.pdf','2021-05-28 18:29:17','2021-05-28 18:29:46',1663504095587);
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_am` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'Hayeren','Армянский','Armenian','2021-05-12 21:00:12','2021-05-28 18:21:52',0),(2,'1','2','3','2021-05-25 20:58:51','2021-05-28 18:21:35',1),(4,'123','12414221','15512521','2021-05-25 21:04:30','2021-05-28 18:21:34',1),(5,'Ruseren','Русский','Russian','2021-05-28 18:22:02','2021-05-28 18:22:02',0),(6,'Angleren','Английский','English','2021-05-28 18:22:16','2021-05-28 18:22:16',0);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `success` tinyint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'afsfasfsa',1,'2021-05-24 21:28:45',NULL);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2021_05_25_104819_create_books_table',2),(5,'2021_05_25_104836_create_authors_table',2),(6,'2021_05_25_104923_create_sections_table',2),(7,'2021_05_25_105113_create_donations_table',2),(8,'2021_05_25_105120_create_payments_table',2),(9,'2021_05_25_105129_create_subscriptions_table',2),(10,'2021_05_25_110047_create_languages_table',2),(11,'2021_05_25_111136_create_files_table',2),(12,'2021_05_25_111913_create_messages_table',2),(13,'2021_05_25_114213_create_types_table',3),(14,'2021_05_27_220001_create_favorites_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('vmxitaryan@gmail.com','$2y$10$R6SqWqmNMfbD0dsH3qYzZe4lNnITCQn3w4ZqhBiCOC.pupXzBpuym','2021-05-25 07:59:01');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title_am` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,'sec12a','sec12','sec123',0,'2021-05-13 21:04:00','2021-05-28 18:07:26',1),(3,'afsfsa','fsafsafsa','fsafsa',0,'2021-05-25 21:13:56','2021-05-28 18:07:24',1),(4,'asf','2355','54758685',0,'2021-05-25 21:14:17','2021-05-28 18:07:21',1),(5,'saffsa','fsafsafsa','fasfsa',0,'2021-05-25 21:16:05','2021-05-28 18:07:19',1),(6,'afsfsa','fsafsafsa','fsafsa',0,'2021-05-25 21:16:28','2021-05-28 18:06:06',1),(7,'Heqiatner','Skazki','Tales',0,'2021-05-28 18:07:43','2021-05-28 18:07:43',0),(8,'Vep','Веп','Vep (english)',0,'2021-05-28 18:08:28','2021-05-28 18:08:28',0);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` bigint unsigned DEFAULT NULL,
  `payment_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email-unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,NULL,'vauagma@gmail.com',NULL,NULL,'2021-05-19 21:27:01',NULL),(3,NULL,'vauagma@gmail.coms',NULL,NULL,'2021-05-19 21:27:01',NULL),(4,NULL,'asf@af.saf',NULL,NULL,'2021-05-25 22:15:41','2021-05-25 22:15:41'),(6,NULL,'atat.asggas@agsgsa.sag',NULL,NULL,'2021-05-25 22:16:37','2021-05-25 22:16:37'),(7,NULL,'vmxitaryan@gmail.com',NULL,NULL,'2021-05-25 22:17:52','2021-05-25 22:17:52'),(8,NULL,'asfafs@gagas.ah',NULL,NULL,'2021-05-25 22:18:05','2021-05-25 22:18:05'),(9,NULL,'asfafs@afsfas.saf',NULL,NULL,'2021-05-25 22:18:49','2021-05-25 22:18:49'),(10,1,'bub@asg.ags',NULL,NULL,'2021-05-25 22:20:38','2021-05-25 22:20:38'),(11,NULL,'afs2@afs.ags',NULL,NULL,'2021-05-25 22:21:20','2021-05-25 22:21:20'),(12,1,'asf@ags.asg',NULL,NULL,'2021-05-25 22:22:17','2021-05-25 22:22:17'),(13,1,'saffas@ags.asg',NULL,NULL,'2021-05-25 22:23:14','2021-05-25 22:23:14'),(14,NULL,'ata@tata.at',NULL,NULL,'2021-05-25 22:25:07','2021-05-25 22:25:07'),(15,NULL,'asfaf@afs.asf',NULL,NULL,'2021-05-25 22:25:16','2021-05-25 22:25:16'),(16,NULL,'asfaf@afs.asfas',NULL,NULL,'2021-05-25 22:25:19','2021-05-25 22:25:19'),(17,NULL,'asfaf@afs.asf3',NULL,NULL,'2021-05-25 22:25:22','2021-05-25 22:25:22'),(18,NULL,'asfaf@afs.asf356236',NULL,NULL,'2021-05-25 22:25:25','2021-05-25 22:25:25'),(19,NULL,'some-email@com.com',NULL,NULL,'2021-05-25 22:30:45','2021-05-25 22:30:45'),(20,NULL,'salvadordali.news@gmail.com',NULL,NULL,'2021-05-27 15:13:59','2021-05-27 15:13:59');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `types`
--

DROP TABLE IF EXISTS `types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_am` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_ru` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types`
--

LOCK TABLES `types` WRITE;
/*!40000 ALTER TABLE `types` DISABLE KEYS */;
INSERT INTO `types` VALUES (1,'type1','type12','type123','type1234','2021-05-25 20:49:24','2021-05-28 18:09:01',1),(2,'asaafsfsafsa','asaafsfsafsa','afsfsafsa','asff','2021-05-25 20:54:16','2021-05-28 18:09:03',1),(4,'saffsa','saffsa','asffsfsa','fsafsa','2021-05-25 21:12:26','2021-05-28 18:09:02',1),(5,'Hatuk tip','Hatuk tip','Специальный тип','Special type','2021-05-28 18:20:50','2021-05-28 18:20:50',0),(6,'Normal tip','Normal tip','Нормальный тип','Normal type','2021-05-28 18:21:28','2021-05-28 18:21:28',0);
/*!40000 ALTER TABLE `types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance` int NOT NULL DEFAULT '0',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` enum('user','admin','manager','contributor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` enum('active','passive') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Vardan','Mkhitaryanee','077 774564',890000,'vmxitaryan@gmail.com',NULL,'$2y$10$KfBwVOcv3i/JF.whhxNdIu2loODDskd0npwv0W3TqZLLOFRPnrtVa',NULL,'2021-05-24 19:02:24','2021-05-25 08:45:53','admin','active'),(2,'Test','','',0,'test@gmail.com',NULL,'$2y$10$KfBwVOcv3i/JF.whhxNdIu2loODDskd0npwv0W3TqZLLOFRPnrtVa',NULL,'2021-05-24 19:02:24','2021-05-24 19:02:24','user','active'),(3,'Arsen','','',0,'arsen@tumanyan.am',NULL,'$2y$10$KfBwVOcv3i/JF.whhxNdIu2loODDskd0npwv0W3TqZLLOFRPnrtVa',NULL,'2021-05-24 19:02:24','2021-05-24 19:02:24','admin','active'),(4,'VARDAN','',NULL,0,'root@ags',NULL,'$2y$10$35IdhOKNaK3qGLTBGC6RnOqDvHjcZPWmXTEQWcVqvo4IlkFWyUZHK',NULL,'2021-05-25 08:09:15','2021-05-25 08:09:15','user','active'),(5,'VARDAN','MKHITARYAN','3024148567',0,'john@mail.com',NULL,'$2y$10$3ILO6ZfhpqRx5CNPqVLgP.aoKCD93vjfDJ0jvq9hHhdEhDErgjNfy',NULL,'2021-05-25 08:10:58','2021-05-25 08:10:58','user','active');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-29 17:01:01
