<div>
	<div class="row justify-content-center d-flex">
		<span>{{ __( 'Other links' ) }}</span>
		<a href="" class="btn btn-primary">Some</a>
		<a href="" class="btn btn-primary">Some</a>
		<a href="" class="btn btn-primary">Some</a>
		<a href="" class="btn btn-primary">Some</a>
	</div>
</div>