<?php 
phpinfo();